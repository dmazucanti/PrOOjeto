import login.*;

public class TesteAutenticacao {

	public static void main(String[] args) throws Exception {
		VerificaSenha autentic = new VerificaSenha();
		
		System.out.println("Sucesso!");
	}

}
